class AppSecrets {
  static const String appwriteProjectId  = '69760bbc0001fa156942';
  static const String appwriteBucketId  = '6976483e000128bca827';
    static const String anonKey =
      'sb_publishable_8Uc_5jD0Uf4lvtkDuzrizQ_22a64W4J';
}
