class Failure {
  final String errorMessage;

  const Failure({required this.errorMessage});
}
