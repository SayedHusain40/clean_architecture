class PostParams {
  final String id;

  const PostParams({required this.id});
}