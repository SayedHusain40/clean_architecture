class UserParams {
  final String id;

  const UserParams({required this.id});
}