class AddressEntity {
  final String home;

  const AddressEntity({required this.home}); 
}